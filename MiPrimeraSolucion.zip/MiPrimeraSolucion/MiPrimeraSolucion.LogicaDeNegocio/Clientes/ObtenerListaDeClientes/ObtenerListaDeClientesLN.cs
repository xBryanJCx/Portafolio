using MiPrimeraSolucion.Abstracciones.LogicaDeNegocio.Clientes.ObtenerListaDeClientes;
using MiPrimeraSolucion.Abstracciones.ModelosParaUI.Clientes;
using System;
using System.Collections.Generic;

namespace MiPrimeraSolucion.LogicaDeNegocio.Clientes.ObtenerListaDeClientes
{
    public class ObtenerListaDeClientesLN : IObtenerListaDeClientesLN
    {
        public List<ClientesDto> Obtener()
        {
            List<ClientesDto> laListaDeClientes = new List<ClientesDto>();
            // TODO: Implement actual data access logic
            laListaDeClientes.Add(new ClientesDto
            {
                identificacion = "1-1234-5678",
                nombre = "Juan",
                primerApellido = "P�rez",
                segundoApellido = "Gonz�lez",
                telefono = "8888-8888",
                correo = "juan@email.com",
                fechaDeRegistro = DateTime.Now,
                estado = true
            });
            return laListaDeClientes;
        }
    }
}