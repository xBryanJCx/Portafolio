﻿namespace MiPrimeraSolucion.Calculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNumero1 = new System.Windows.Forms.Button();
            this.txtVentanaDeResultados = new System.Windows.Forms.TextBox();
            this.btnNumero2 = new System.Windows.Forms.Button();
            this.btnNumero3 = new System.Windows.Forms.Button();
            this.btnSuma = new System.Windows.Forms.Button();
            this.btnNumero4 = new System.Windows.Forms.Button();
            this.btnNumero5 = new System.Windows.Forms.Button();
            this.btnNumero6 = new System.Windows.Forms.Button();
            this.btnNumero7 = new System.Windows.Forms.Button();
            this.btnNumero8 = new System.Windows.Forms.Button();
            this.btnNumero9 = new System.Windows.Forms.Button();
            this.btnResta = new System.Windows.Forms.Button();
            this.btnMultiplicacion = new System.Windows.Forms.Button();
            this.btnDivision = new System.Windows.Forms.Button();
            this.btnIgual = new System.Windows.Forms.Button();
            this.btnNumero0 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnNumero1
            // 
            this.btnNumero1.Location = new System.Drawing.Point(28, 109);
            this.btnNumero1.Name = "btnNumero1";
            this.btnNumero1.Size = new System.Drawing.Size(52, 44);
            this.btnNumero1.TabIndex = 4;
            this.btnNumero1.Text = "1";
            this.btnNumero1.UseVisualStyleBackColor = true;
            // 
            // txtVentanaDeResultados
            // 
            this.txtVentanaDeResultados.Location = new System.Drawing.Point(28, 46);
            this.txtVentanaDeResultados.Name = "txtVentanaDeResultados";
            this.txtVentanaDeResultados.Size = new System.Drawing.Size(283, 20);
            this.txtVentanaDeResultados.TabIndex = 5;
            // 
            // btnNumero2
            // 
            this.btnNumero2.Location = new System.Drawing.Point(107, 109);
            this.btnNumero2.Name = "btnNumero2";
            this.btnNumero2.Size = new System.Drawing.Size(52, 44);
            this.btnNumero2.TabIndex = 6;
            this.btnNumero2.Text = "2";
            this.btnNumero2.UseVisualStyleBackColor = true;
            // 
            // btnNumero3
            // 
            this.btnNumero3.Location = new System.Drawing.Point(191, 109);
            this.btnNumero3.Name = "btnNumero3";
            this.btnNumero3.Size = new System.Drawing.Size(52, 44);
            this.btnNumero3.TabIndex = 7;
            this.btnNumero3.Text = "3";
            this.btnNumero3.UseVisualStyleBackColor = true;
            // 
            // btnSuma
            // 
            this.btnSuma.Location = new System.Drawing.Point(277, 109);
            this.btnSuma.Name = "btnSuma";
            this.btnSuma.Size = new System.Drawing.Size(52, 44);
            this.btnSuma.TabIndex = 8;
            this.btnSuma.Text = "+";
            this.btnSuma.UseVisualStyleBackColor = true;
            // 
            // btnNumero4
            // 
            this.btnNumero4.Location = new System.Drawing.Point(28, 192);
            this.btnNumero4.Name = "btnNumero4";
            this.btnNumero4.Size = new System.Drawing.Size(52, 44);
            this.btnNumero4.TabIndex = 9;
            this.btnNumero4.Text = "4";
            this.btnNumero4.UseVisualStyleBackColor = true;
            // 
            // btnNumero5
            // 
            this.btnNumero5.Location = new System.Drawing.Point(107, 192);
            this.btnNumero5.Name = "btnNumero5";
            this.btnNumero5.Size = new System.Drawing.Size(52, 44);
            this.btnNumero5.TabIndex = 10;
            this.btnNumero5.Text = "5";
            this.btnNumero5.UseVisualStyleBackColor = true;
            // 
            // btnNumero6
            // 
            this.btnNumero6.Location = new System.Drawing.Point(191, 192);
            this.btnNumero6.Name = "btnNumero6";
            this.btnNumero6.Size = new System.Drawing.Size(52, 44);
            this.btnNumero6.TabIndex = 11;
            this.btnNumero6.Text = "6";
            this.btnNumero6.UseVisualStyleBackColor = true;
            // 
            // btnNumero7
            // 
            this.btnNumero7.Location = new System.Drawing.Point(28, 263);
            this.btnNumero7.Name = "btnNumero7";
            this.btnNumero7.Size = new System.Drawing.Size(52, 44);
            this.btnNumero7.TabIndex = 12;
            this.btnNumero7.Text = "7";
            this.btnNumero7.UseVisualStyleBackColor = true;
            // 
            // btnNumero8
            // 
            this.btnNumero8.Location = new System.Drawing.Point(107, 263);
            this.btnNumero8.Name = "btnNumero8";
            this.btnNumero8.Size = new System.Drawing.Size(52, 44);
            this.btnNumero8.TabIndex = 13;
            this.btnNumero8.Text = "8";
            this.btnNumero8.UseVisualStyleBackColor = true;
            // 
            // btnNumero9
            // 
            this.btnNumero9.Location = new System.Drawing.Point(191, 263);
            this.btnNumero9.Name = "btnNumero9";
            this.btnNumero9.Size = new System.Drawing.Size(52, 44);
            this.btnNumero9.TabIndex = 14;
            this.btnNumero9.Text = "9";
            this.btnNumero9.UseVisualStyleBackColor = true;
            // 
            // btnResta
            // 
            this.btnResta.Location = new System.Drawing.Point(277, 192);
            this.btnResta.Name = "btnResta";
            this.btnResta.Size = new System.Drawing.Size(52, 44);
            this.btnResta.TabIndex = 17;
            this.btnResta.Text = "-";
            this.btnResta.UseVisualStyleBackColor = true;
            // 
            // btnMultiplicacion
            // 
            this.btnMultiplicacion.Location = new System.Drawing.Point(277, 263);
            this.btnMultiplicacion.Name = "btnMultiplicacion";
            this.btnMultiplicacion.Size = new System.Drawing.Size(52, 44);
            this.btnMultiplicacion.TabIndex = 18;
            this.btnMultiplicacion.Text = "*";
            this.btnMultiplicacion.UseVisualStyleBackColor = true;
            // 
            // btnDivision
            // 
            this.btnDivision.Location = new System.Drawing.Point(277, 332);
            this.btnDivision.Name = "btnDivision";
            this.btnDivision.Size = new System.Drawing.Size(52, 44);
            this.btnDivision.TabIndex = 19;
            this.btnDivision.Text = "/";
            this.btnDivision.UseVisualStyleBackColor = true;
            // 
            // btnIgual
            // 
            this.btnIgual.Location = new System.Drawing.Point(191, 332);
            this.btnIgual.Name = "btnIgual";
            this.btnIgual.Size = new System.Drawing.Size(52, 44);
            this.btnIgual.TabIndex = 20;
            this.btnIgual.Text = "=";
            this.btnIgual.UseVisualStyleBackColor = true;
            // 
            // btnNumero0
            // 
            this.btnNumero0.Location = new System.Drawing.Point(28, 332);
            this.btnNumero0.Name = "btnNumero0";
            this.btnNumero0.Size = new System.Drawing.Size(131, 44);
            this.btnNumero0.TabIndex = 21;
            this.btnNumero0.Text = "0";
            this.btnNumero0.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(341, 450);
            this.Controls.Add(this.btnNumero0);
            this.Controls.Add(this.btnIgual);
            this.Controls.Add(this.btnDivision);
            this.Controls.Add(this.btnMultiplicacion);
            this.Controls.Add(this.btnResta);
            this.Controls.Add(this.btnNumero9);
            this.Controls.Add(this.btnNumero8);
            this.Controls.Add(this.btnNumero7);
            this.Controls.Add(this.btnNumero6);
            this.Controls.Add(this.btnNumero5);
            this.Controls.Add(this.btnNumero4);
            this.Controls.Add(this.btnSuma);
            this.Controls.Add(this.btnNumero3);
            this.Controls.Add(this.btnNumero2);
            this.Controls.Add(this.txtVentanaDeResultados);
            this.Controls.Add(this.btnNumero1);
            this.Name = "Form1";
            this.Text = "Form1";

            // Conectar eventos de números
            this.btnNumero0.Click += new System.EventHandler(this.btnNumero0_Click);
            this.btnNumero1.Click += new System.EventHandler(this.btnNumero1_Click);
            this.btnNumero2.Click += new System.EventHandler(this.btnNumero2_Click);
            this.btnNumero3.Click += new System.EventHandler(this.btnNumero3_Click);
            this.btnNumero4.Click += new System.EventHandler(this.btnNumero4_Click);
            this.btnNumero5.Click += new System.EventHandler(this.btnNumero5_Click);
            this.btnNumero6.Click += new System.EventHandler(this.btnNumero6_Click);
            this.btnNumero7.Click += new System.EventHandler(this.btnNumero7_Click);
            this.btnNumero8.Click += new System.EventHandler(this.btnNumero8_Click);
            this.btnNumero9.Click += new System.EventHandler(this.btnNumero9_Click);

            // Conectar eventos de operaciones
            this.btnSuma.Click += new System.EventHandler(this.btnSuma_Click);
            this.btnResta.Click += new System.EventHandler(this.btnResta_Click);
            this.btnMultiplicacion.Click += new System.EventHandler(this.btnMultiplicacion_Click);
            this.btnDivision.Click += new System.EventHandler(this.btnDivision_Click);
            this.btnIgual.Click += new System.EventHandler(this.btnIgual_Click);

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button btnNumero1;
        private System.Windows.Forms.TextBox txtVentanaDeResultados;
        private System.Windows.Forms.Button btnNumero2;
        private System.Windows.Forms.Button btnNumero3;
        private System.Windows.Forms.Button btnSuma;
        private System.Windows.Forms.Button btnNumero4;
        private System.Windows.Forms.Button btnNumero5;
        private System.Windows.Forms.Button btnNumero6;
        private System.Windows.Forms.Button btnNumero7;
        private System.Windows.Forms.Button btnNumero8;
        private System.Windows.Forms.Button btnNumero9;
        private System.Windows.Forms.Button btnResta;
        private System.Windows.Forms.Button btnMultiplicacion;
        private System.Windows.Forms.Button btnDivision;
        private System.Windows.Forms.Button btnIgual;
        private System.Windows.Forms.Button btnNumero0;
    }
}